
/**
 * @ignore
 */
export const environment = {
  /**
 * @ignore
 */
  production: true
};
